import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const [MovieName, setMovieName] = useState("");
  const navigate = useNavigate();
  const HandleSubmit = async () => {
    const result = await fetch(
      `http://www.omdbapi.com/?t=${MovieName}&&apikey=8ab0c440`
      
    );
    const data = await result.json();
    console.log(data)
    if (!data.imdbID) {
      alert("no movie found");
      return;
    }
    navigate(`/detailid/${data.imdbID}`); 
  };

  return (
    <>
      <h1 className="flex justify-center text-red-500 font-bold m-5 text-3xl">
        TIWARI MOVIE{" "}
      </h1>
      <div className="flex justify-center">
        <input
          type="text"
          className="border-2 bg-red-300 p-3"
          placeholder="Search Movie name"
          onChange={(e) => {
            setMovieName(e.target.value);
          }}
        />
        <button
          className="bg-orange-200 rounded-2xl border-1 p-3 m-3 text-xl"
          onClick={HandleSubmit}
        >
          Search
        </button>
      </div>
    </>
  );
};

export default Home;
