import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Loader } from "lucide-react";
interface MovieData {
  Title: string;
  Year: string;
  Director: string;
  Actors: string;
  Plot: string;
  Poster: string;
}

const DetailMovie = () => {
  const { imdbID } = useParams();
  const [data, setData] = useState<MovieData | null>(null);
  const [isloading, setisLoading] = useState(true);
  useEffect(() => {
    fetch(`http://www.omdbapi.com/?i=${imdbID}&&apikey=8ab0c440`)
      .then((res) => res.json())
      .then((data) => setData(data))
      .then(() => setisLoading(false))
      .catch((err) => console.log(err));
  }, [imdbID]);

  if (isloading) {
    return <Loader size={48} fill="red" />;
  }
  return (
    <div>
      {
        <div className="flex justify-center">
          <div className="flex  m-5 p-5 bg-red-300 rounded-2xl">
            <img src={data?.Poster} alt="poster" className="rounded-2xl" />
            <div>
              <h1 className="text-3xl font-bold text-center"> <span className="font-semibold ">Movie Name</span> :{data?.Title}</h1>
              <h1 className="text-2xl font-bold text-center"><span className="font-semibold ">Year:</span> {data?.Year}</h1>
              <h1 className="text-2xl font-bold text-center">
                {data?.Director}
              </h1>
              <h1 className="text-2xl font-bold text-center">{data?.Actors}</h1>
              <h1 className="text-2xl font-bold text-center">{data?.Plot}</h1>
            </div>
          </div>
        </div>
      }
    </div>
  );
};

export default DetailMovie;
